# ipl-win-probability-predictor
A machine learning project to find out the win probability of an IPL match
